var countdown;
var countdown_number;

var countDownElem = document.getElementById('time');

function countdown_trigger() {
    countdown_number--;
    countDownElem.innerHTML = (countdown_number/100).toFixed(2);
    if(countdown_number > 0) {
        countdown = setTimeout('countdown_trigger()', 10);
    }
    else {
    	countDownElem.parentNode.innerHTML = "Redirecting...";
    	window.location.replace(app.outUrl);
    }
}

(function countdown_init() {
    countdown_number = 250;
    countdown_trigger();
})();
