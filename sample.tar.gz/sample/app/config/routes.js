/**
* Controllers
*/

var core = require('../../core/controllers/index'),
	pages = require('../controllers/pages');


/**
* Expose routes
*/
module.exports = function (app) {
	// home route
	app.get('/', core.home.index);

	// voucher routes
	app.get('/top20', core.vouchers.top20);

	// category pages
	app.get('/kategorii', core.categories.home);
	// category page
	app.get('/kategorii/:categoryName', core.categories.category);

	// all retailers page (all stores)
	app.get('/vse-magazini', core.retailers.index);

	// retailer details page
	app.get('/retailer/:name', core.retailers.details);

	// clickout router that redirects to cuponation page
	app.get('/co/:voucherId', core.clickout.bridge);

	//router for ajax voucher clickout info
	app.get('/v/:voucherId', core.ajax.voucherPopup);
	app.get('/vd/:voucherId', core.ajax.voucherDetails);

	app.get('/search', core.search.index);

	app.get('/pravila', pages.pravila);
	app.get('/oferta', pages.oferta);
	app.get('/pomosch', pages.pomosch);
	app.get('/politika-konfidencialnosti', pages.politika);
	app.get('/presse', pages.presse);
	app.get('/o-nas', pages.about);
	app.get('/partnyori', pages.partnyori);
	app.get('/globalnie', pages.global);
};