exports.pravila = function(req, res) {
	res.redirect('/oferta');
};

exports.oferta = function(req, res) {
	res.render('pages/oferta');
};

exports.pomosch = function(req, res) {
	res.render('pages/pomosch');
};

exports.politika = function(req, res) {
	res.render('pages/politika');
};

exports.presse = function(req, res) {
	res.render('pages/presse');
};

exports.about = function(req, res) {
	res.render('pages/about');
};

exports.partnyori = function(req, res) {
	res.render('pages/partnyori');
};

exports.global = function(req, res) {
	res.render('pages/global');
};