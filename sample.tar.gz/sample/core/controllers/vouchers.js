/**
 * Module dependencies.
 */

var mongoose = require('mongoose')
	, Voucher = mongoose.model('Voucher')
	, Category = mongoose.model('Category')
	, Retailer = mongoose.model('Retailer')
	, async = require('async')
	, viewData = {}
	, redis = require("redis")
	, client = redis.createClient()

// top 20 controller
exports.top20 = function(req, res) {
	client.get(req.redisKey, function(err, reply){ 

		if (!err && !!reply) {
			var jsonData = JSON.parse(reply);
			return res.render('vouchers/top20', jsonData);
		}
		async.parallel([
			function(callback) {
				Voucher.getTop20(function(err, data){
					if (!err && !!data) {
						viewData.vouchers = data;
						
					}
					callback()
				})
			},
			
			function(callback) {
				Category.getAll(function(err, data) {
					if (!err && !!data) {
						viewData.categories = data;
					}
					callback()
				})
			},
			
			function(callback) {
				Retailer.getCategoryRetailerByName('electronicscoupons', function(err, data) {
					if (!err && data.length > 0) {
						viewData.retailers = data;
					}
					callback()
				})
			}
		],

		function(err) {
			if (err) return next(err);

			viewData.title = 'Top Vouchers ';
			viewData.metaDescription = 'The Top Vouchers at Oneindia.in, a large online portal that brings Breaking & Latest current news headlines from India';
			client.set(req.redisKey, JSON.stringify(viewData), function() {
				res.render('vouchers/top20', viewData);
			});
		})
	})
}