/**
 * Module dependencies.
 */
var mongoose = require('mongoose')
	, Voucher = mongoose.model('Voucher')
	, async = require('async')
	, viewData = {}

exports.bridge = function(req, res) {
	async.parallel([
		function(callback) {
			Voucher.findById(req.params.voucherId, function(err, data) {
				if (!err && data.length > 0) {
					viewData.voucher = data[0];
				}
				callback()
			})
		}
	],

	function(err) {
		if (err) return next(err);
		
		//NB: referer and requestUri should already be in the session
		var referer = req.session.referer || ''
			, requestUri = req.session.requestUri || ''
			, voucherId = req.params.voucherId || false
            , conf = req.conf;
		
		//the actual referer (not from the session) will be used
		//on clickout tracking to identify the WL page (i.e. top20 that the user came from)
		breadcrumbs = req.headers.referer || '';

		//NB: don't test for referer as in some cases it might be empty
		if (!viewData.voucher || !conf || ! requestUri) res.redirect('/404');

   		var url = conf.clickoutUrl + voucherId 
   				//we need to pass referrerUri & breadcrumbs & requestUri so that the cuponation tracking logic
   				//matches this clickout with the customer_referral_url at the start of the session
				+ '?referrerUri=' + referer 
				+ '&breadcrumbs=' + (new Buffer(breadcrumbs).toString('base64'))  
				+ '&requestUri=' + requestUri;

		res.render('clickout/bridge', {voucher: viewData.voucher, url: url});
	});
	
};
