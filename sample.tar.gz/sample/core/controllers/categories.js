/**
 * Module dependencies.
 */
var mongoose = require('mongoose')
	, Category = mongoose.model('Category')
	, Voucher = mongoose.model('Voucher')
	, Retailer = mongoose.model('Retailer')
	, SeoTag = mongoose.model('SeoTag')
	, async = require('async')
	, viewData = {}
	, seoTags = {}
	, redis = require("redis")
	, client = redis.createClient()


exports.home = function(req, res) {
	client.get(req.redisKey, function(err, reply) {

		if (!err && !!reply) {
			var jsonData = JSON.parse(reply);
			return res.render('categories/home', jsonData);
		} 
		async.parallel([
			function(callback) {
				Category.getAll(function(err, data) {
					if (!err && !!data) {
						viewData.categories = data;
					}
					callback()
				})
			},
			
			function(callback) {
				SeoTag.getAll(function(err, data) {
					if (!err && !!data) {
						seoTags = data;

						viewData.title = 'Categories - Sales and Discount Vouchers at Coupons Oneindia';
						viewData.metaDescription = 'Coupons for various Categories at Oneindia.in, a large online portal that brings Breaking & Latest current news headlines from India';
						viewData.metaKeywords = 'Electronics Coupon Codes, fashion & apparel Discount Coupons, books Promo Codes, movies Deals, music, flowers gifts';
						viewData.voucherKw = seoTags.__voucher_kw__;
						viewData.seoDate = seoTags.__year__;
					}


					
					callback();
				});
			}
		],

		function(err) {
			if (err) return next(err);
			
			client.set(req.redisKey, JSON.stringify(viewData), function() {
				res.render('categories/home', viewData);
			});
		});
	});
}


exports.category = function(req, res) {
	client.get(req.redisKey, function(err, reply) {
		if (!err && !!reply) {
			var jsonData = JSON.parse(reply);
			return res.render('categories/category', jsonData);
		} 

		async.series([
			function(callback) {
				Category.getCatByName(req.params.categoryName, function(err, data) {
					if (err || data.length < 0) return callback('error');
					if (!err && data.length > 0) {
						viewData.category = data[0];
					}
					callback()
				})
			}, 

			function(callback) {
				if (!viewData || !viewData.category) return callback('error');
				var catName = viewData.category.name;
				Voucher.getByCategoryName(catName, 999, function(err, data) {
					if (err || data.length < 0) return callback('error');
					if (!err && data.length > 0) {
						viewData.vouchers = data;
					}
					callback()
				})
			}, 

			function(callback) {
				Retailer.getCategoryRetailerByName(req.params.categoryName, function(err, data) {
					if (err || data.length < 0) return callback('error');
					if (!err && data.length > 0) {

						viewData.retailers = data;
					}
					callback()
				})
			},

			function(callback) {
				Category.getAll(function(err, data) {
					if (!err && !!data) {
						
						viewData.categories = data;
					}
					callback()
				})
			},
			
			function(callback) {
				SeoTag.getAll(function(err, data) {
					if (!err && !!data) {
						seoTags = data;
						viewData.title = seoTags.categoryTitle
								.replace(/__category_name__/g, viewData.category.name) 
								.replace(/__voucher_kw__/g, seoTags.__voucher_kw__) 
								.replace(/__year__/g, seoTags.__year__);
			
						viewData.metaDescription = seoTags.categoryMetaDescription
											.replace(/__category_name__/g, viewData.category.name) 
											.replace(/__voucher_kw__/g, seoTags.__voucher_kw__) 
											.replace(/__year__/g, seoTags.__year__);
						
						viewData.voucherKw = seoTags.__voucher_kw__;
						viewData.seoDate = seoTags.__year__;
					}
					
					callback();
				});
			}
		],

		function(err) {
			if (err) {
				res.redirect('/404')
				return;
			}
			client.set(req.redisKey, JSON.stringify(viewData), function() {
				res.render('categories/category', viewData);
			});
		});
	});
}
