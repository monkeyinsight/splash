var async = require('async');
/**
 * Module dependencies.
 */
var mongoose = require('mongoose')
	, Retailer = mongoose.model('Retailer')
	, Voucher = mongoose.model('Voucher')
	, FeaturedCategories = mongoose.model('FeaturedCategories')
	, SeoTag = mongoose.model('SeoTag')
	, redis = require("redis")
	, client = redis.createClient()
	, seoTags = {}

/**
 * data for the rendering of the front page
 * @type {Object}
 */
var viewData = {};

// home action
exports.index = function(req, res) {
	client.get(req.redisKey, function(err, reply){ 

		if (!err && !!reply) {
			var jsonData = JSON.parse(reply);
			return res.render('home/index', jsonData);
		}

		async.parallel([
			function(callback) {
				Retailer.getTop10ForHomePage(10, function(err, data) {
					if (!err && !!data) {
						viewData.retailers = data;
					}
					callback()
				})
			},

			function(callback) {
				Retailer.getBannerRetailers(10, function(err, data) {
					if (!err && !!data)  {
						viewData.banners = data;
					}
					callback()
				})
			},

			function(callback) {
				Voucher.getTop20(function(err, data) {
					if (!err && !!data) {
						viewData.vouchers = data;
					}
					callback()
				})
			}, 

			function(callback) {
				FeaturedCategories.getAll(function(err, data) {
					if (!err && !!data) {
						viewData.featuredCategories = data;
					}
					callback()
				})
			},
			
			function(callback) {
				SeoTag.getAll(function(err, data) {
					if (!err && !!data) {
						seoTags = data;
					}
					
					callback();
				});
			}

		], 

		function(err) {
			if (err) return next(err);
			viewData.title = 'Online Coupons ' + seoTags.__year__;
			viewData.metaDescription = 'Find the latest online shopping coupons at Oneindia.in, a large online portal that brings Breaking & Latest current news headlines from India'

			client.set(req.redisKey, JSON.stringify(viewData), function() {
				res.render('home/index', viewData);
			});
		}
		);
	});
}