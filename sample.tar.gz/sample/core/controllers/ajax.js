var async = require('async')
	, mongoose = require('mongoose')
	, Voucher = mongoose.model('Voucher')
	, Retailer = mongoose.model('Retailer')
	, viewData = {};

// getting info for the voucher
exports.voucherPopup = function(req, res) { 
	async.parallel([
		function(callback) {
			Voucher.findById(req.params.voucherId, function(err, data) {
				if (!err && data.length > 0) {
					viewData.v = data[0];
				}
				callback()
			})
		},

		function(callback) {
			Retailer.getNumberOfRetailers(3, function(err, data) {
				if (!err && data.length > 0) {
					viewData.r = data;
				}
				callback()
			})
		}
	],
	function(err) {
		if (err) return next(err);
		res.render('ajax/clickoutPopup', {v: viewData.v, retailers: viewData.r}, function(err, html) {
			res.send({code: viewData.v.code, html: html})
		});
	})
}




// getting info for the voucher
exports.voucherDetails = function(req, res) { 
	async.parallel([
		function(callback) {
			Voucher.findById(req.params.voucherId, function(err, data) {
				if (!err && data.length > 0) {
					viewData.v = data[0];
				}
				callback()
			})
		}
	],

	function(err) {
		if (err) res.send({error: 'error in ajax call'})
		res.send({description: viewData.v.description})
	})
}