module.exports = {
	home: require('./home'),
	vouchers: require('./vouchers'),
	retailers: require('./retailers'),
	clickout: require('./clickout'),
	categories: require('./categories'),
	ajax: require('./ajax'),
	search: require('./search')
};