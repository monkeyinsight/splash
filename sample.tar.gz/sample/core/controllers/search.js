/**
 * Module dependencies.
 */
var mongoose = require('mongoose')
	, Category = mongoose.model('Category')
	, Retailer = mongoose.model('Retailer')
	, SeoTag = mongoose.model('SeoTag')
	, async = require('async')
	, viewData = {}
	, seoTags = {}
	, solr = require('solr-client')
	, solrUtilClass = require('../wl_library/js/intvou/solrUtil.js')
    , sanitize = require('validator').sanitize



exports.index = function(req, res) {

	var solrClient = solr.createClient({
		host : '127.0.0.1',
		port : '8983',
		core : req.conf.partnerSiteName,
		path : '/solr'
	});

	var solrUtil = solrUtilClass.SolrUtil(solrClient, 'en');

	async.parallel([
		function(callback) {
			SeoTag.getAll(function(err, data) {
				if (!err && !!data) {
					seoTags = data;
				}
				
				callback();
			});
		},

		function(callback) {
			Category.getAll(function(err, data) {
				if (!err && !!data) {
					viewData.categories = data;
				}
				
				callback();
			})
		}, 

		function(callback) {
			if (!req.query.q) return callback();

			var queryString = sanitize(req.query.q).xss();
			var query = solrUtil.query(queryString);

			solrClient.search(query, function(err,obj) {
			   if (err) {
					callback(err);
			   } else{
					var resultObj = obj.response.docs;
					viewData.searchWord = queryString;
					if (resultObj.length < 1) {
						viewData.vouchers = [];
						return callback();
					}

					var tmpObj = [];
					for (i in resultObj) {
						var v =  solrUtil.mapFieldsFromSolrToDB(resultObj[i]);
						tmpObj.push(v);
					}
					
			   		viewData.vouchers = tmpObj;
					callback();
			   }
			});
		}
	],

	function(err) {
		if (err) {
			res.redirect('/search');
			return;
		}
		
		viewData.title = 'Search popular vouchers';
		viewData.metaDescription = 'Search meta description';
		
		res.render('search/home', viewData);
	});
}

