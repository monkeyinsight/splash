/**
 * Module dependencies.
 */
var mongoose = require('mongoose')
	, Retailer = mongoose.model('Retailer')
	, Voucher = mongoose.model('Voucher')
	, Category = mongoose.model('Category')
	, SeoTag = mongoose.model('SeoTag')
	, async = require('async')
	, viewData = {}
	, seoTags = {}
	, redis = require("redis")
	, client = redis.createClient()


exports.index = function(req, res) {
	client.get(req.redisKey, function(err, reply){ 

		if (!err && !!reply) {
			var jsonData = JSON.parse(reply);
			return res.render('retailers/index', jsonData);
		}
		async.parallel([
			function(callback) {
				Retailer.getAll(function(err, data) {
					if (!err && !!data) {
						viewData.retailers = data;
					}
					
					callback();
				});
			},
			
			function(callback) {
				Category.getAll(function(err, data) {
					if (!err && !!data) {
						viewData.categories = data;
					}
					
					callback();
				});
			},
			
			function(callback) {
				SeoTag.getAll(function(err, data) {
					if (!err && !!data) {
						seoTags = data;
					}
					
					callback();
				});
			}
		],

		function(err) {
			if (err) return next(err);

			viewData.title = 'Retailer & All Shops - Sales and Discount Vouchers at Coupons Oneindia '
			viewData.metaDescription = 'Do Online shopping  & Save money with dozens of Coupon Codes, Discount Coupons, Promo Codes, Offers, Deals with shops like Flipkart, myntra, Jabong, FirstCry only on Coupons Oneindia.'
			viewData.metaKeywords = 'Flipkart Coupon Codes, myntra Discount Coupons, Jabong Promo Codes, FirstCry Deals'
				
			if(!seoTags || seoTags.length < 1) return res.redirect('/404');

			viewData.voucherKw = seoTags.__voucher_kw__;
			viewData.seoDate = seoTags.__year__;
			
			client.set(req.redisKey, JSON.stringify(viewData), function() {
				res.render('retailers/index', viewData);
			});
		});
	});
}


// retailer details page
exports.details = function(req, res) {

	client.get(req.redisKey, function(err, reply){ 

		if (!err && !!reply) {
			var jsonData = JSON.parse(reply);
			return res.render('retailers/details', jsonData);
		}
		viewData.retailersForSeo = 	['babyoye-coupons','ebay-india-coupons', 'expedia-india-coupons', 
									'firstcry-coupon','flipkart-coupons', 'goibibo-discount-coupons',
									'jabong-coupons', 'lenskart-coupon', 'makemytrip-coupons', 
									'myntra-coupons', 'snapdeal-coupons', 'tradus-coupons',
									'amazon-coupons', 'zivame-coupons', 'fashionandyou-coupons', 
									'fashionara-coupons', 'fabfurnish-coupons', 'jet-airways-coupon',
									'dominos-india-coupons', 'yatra-coupons'];
		async.series([
			function(callback) {
				Retailer.findByName(req.params.name, function(err, data) {
					if (!err) {
						viewData.retailer = data[0];
					}
					callback()
				})
			},
			
			function(callback) {
				SeoTag.getAll(function(err, data) {
					if (!err) {		
						seoTags = data;
						
						if(!seoTags || seoTags.length < 1) return callback({error: 'empty SeoTags object'});
						
						//sometimes viewData.retailer if filled in later, we need to take care of that case
						var retailerName = '';
						if (viewData.retailer) {
							retailerName = viewData.retailer.name;
						}

						viewData.title = seoTags.siteWideTitle
											.replace(/__retailer_name__/g, retailerName) 
											.replace(/__voucher_kw__/g, seoTags.__voucher_kw__) 
											.replace(/__year__/g, seoTags.__year__);
						
						viewData.metaDescription = seoTags.siteWideMetaDesc
											.replace(/__retailer_name__/g, retailerName) 
											.replace(/__voucher_kw__/g, seoTags.__voucher_kw__) 
											.replace(/__year__/g, seoTags.__year__);


						viewData.metaKeywords = "__retailer_name__ Coupon Codes, __retailer_name__ Discount Coupons, __retailer_name__ Promo Codes, __retailer_name__ Offers, __retailer_name__ Deals"
											.replace(/__retailer_name__/g, retailerName) 
											
					}
					
					callback();
				});
			},

			function(callback) {
				if (!viewData.retailer || viewData.retailer.length < 1) {
					return callback('err');
				}
				var id = viewData.retailer.id;

				Voucher.findByRetailerId(id, function(err, data) {
					if (!err) {
						viewData.vouchers = data;
					}
					callback()
				})
			},
			
			function(callback) {
				Category.getAll(function(err, data) {
					if (!err) {
						viewData.categories = data;
					}
					
					callback();
				})
			},
		],

		function(err) {
			if (err) {
				res.redirect('/404');
				return;
			}
			client.set(req.redisKey, JSON.stringify(viewData), function() {
				res.render('retailers/details', viewData);
			});
		});
	});
}