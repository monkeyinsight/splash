 /**
 * Module dependencies.
 */
var mongoose = require('mongoose')
	, Schema = mongoose.Schema;

/**
 * Category Schema
 */
var FeaturedCategoriesSchema = new Schema({
	  id_category: { type: String, default: '' }
	, image_alt: { type: String, default: '' }
	, image: { type: String, default: '' }
	, name: { type: String, default: '' }
	, seo_url: { type: String, default: '' }
	, title: { type: String, default: '' }
	, vouchers: []
}, {collection: 'featuredCategories'});

FeaturedCategoriesSchema.statics = {
	/**
	* Get all categories from DB
	*
	* @param {Function} cb
	* @api private
	*/
	getAll: function(cb) {
		return this
				.find({})
				.limit(6)
				.exec(cb);
	}
};

mongoose.model('FeaturedCategories', FeaturedCategoriesSchema);