 /**
 * Module dependencies.
 */
var mongoose = require('mongoose')
	, Schema = mongoose.Schema;


/**
 * FromInfo Schema
 */
var FromInfoSchema = new Schema({
  		  title: { type: String, default: '' }
  		, link: { type: String, default: '' }
	}, 
	{collection: 'fromInfo'})

FromInfoSchema.statics = {
	/**
	* Get all feeds for Trakin
	*
	* @param {Function} cb
	* @api private
	*/
	getAll: function(cb) {
		return this
				.find({})
				.exec(cb);
	},
}

mongoose.model('FromInfo', FromInfoSchema);