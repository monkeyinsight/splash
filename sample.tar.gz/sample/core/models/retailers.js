 /**
 * Module dependencies.
 */
var mongoose = require('mongoose')
	, Schema = mongoose.Schema
	, retailerList = {
		travelcoupons : ['goibibo-discount-coupons', 'makemytrip-coupons', 'expedia-india-coupons', 'yatra-coupons', 'jet-airways-coupon'],
		homelivingindiacoupons : ['pepperfry-coupons', 'snapdeal-coupons', 'naaptol-coupons', 'fabfurnish-coupons', 'tradus-coupons'],
		electronicscoupons: ['ebay-india-coupons', 'amazon-coupons', 'flipkart-coupons', 'tradus-coupons', 'snapdeal-coupons'],
		shoesbagsindiacoupons: ['myntra-coupons', 'jabong-coupons', 'flipkart-coupons', 'yebhi-coupons', 'zovi-coupons'],
		fashionapparelcoupons: ['myntra-coupons', 'jabong-coupons', 'flipkart-coupons', 'fashionara-coupons', 'zovi-coupons'],
		kidsbabycoupons: ['firstcry-coupon', 'babyoye-coupons', 'beebayonline-coupons'],
		booksmoviesmusiccoupons: ['flipkart-coupons', 'amazon-coupons', 'infibeam-coupon', 'amar-chitra-katha-coupons', 'indiaplaza-coupons'],
		healthbeautycoupons: ['healthkart-coupons', 'purplle-coupons', 'good-life-coupons', 'fabulloso-coupons', 'snapdeal-coupons'],
		jewelryaccessoriescoupons: ['lenskart-coupon', 'jabong-coupons', 'watchkart-coupons', 'snapdeal-coupons', 'flipkart-coupons'],
		mobilebroadbandtvcoupons: ['freecharge-coupons', 'komparify-coupons', 'paytm-coupons'],
		restaurantsindiacoupons: ['groupon-coupons', 'dominos-india-coupons', 'foodpanda-coupons', 'justeat-coupons']
	}

/**
 * Retailer Schema
 */
var RetailerSchema = new Schema({
  	id: { type: Number, default: '' }
  , name: { type: String, default: '' }
  , url: { type: String, default: '' }
  , seo_url: { type: String, default: '' }
  , image: { type: String, default: '' }
  , image_thumb: { type: String, default: '' }
  , image_carousel: { type: String, default: '' }
  , image_logo_page: { type: String, default: '' }
  , h1_title: { type: String, default: '' }
  , numberActiveVouchers: { type: Number, default: '' }
});

RetailerSchema.statics = {
	/**
	* Get all retailers from DB
	*
	* @param {Function} cb
	* @api private
	*/
	getAll: function(cb) {
		return this
				.find({})
				.sort('seo_url')
				.exec(cb);
	},

	/**
	* Searching Retailer by Name
	*
	* @param {String} name
	* @param {Function} cb
	* @api private
	*/
	findByName: function(name, cb) {
		return this.find({seo_url: name}).exec(cb);
	},

	/**
	* Getting number of retailers
	*
	* @param {String} name
	* @param {Function} cb
	* @api private
	*/
	getNumberOfRetailers: function(num, cb) {
		return this.find({})
				.limit(num)
				.exec(cb);
	},

	/**
	* Getting the Retailers for Home
	*
	* @param {String} name
	* @param {Function} cb
	* @api private
	*/
	getBannerRetailers: function(num, cb) {
		return this.find({})
				.where('image').ne('')
				.limit(num)
				.exec(cb);
	},

	/**
	* Getting the Retailers for Home
	*
	* @param {String} name
	* @param {Function} cb
	* @api private
	*/
	getTop10ForHomePage: function(num, cb) {
		return this.find({})
				.where('image_carousel').ne('')
				.limit(num)
				.exec(cb);
	},

	/**
	* Getting number of retailers
	*
	* @param {String} name
	* @param {Function} cb
	* @api private
	*/
	getCategoryRetailerByName: function(name, cb) {
		var rName = name.replace(/-/g, '');

		if (!retailerList || !retailerList[rName]) {
			rName = 'electronicscoupons';
		}

		return this.find({})
				.where('seo_url').in(retailerList[rName])
				.exec(cb);
	}

};

mongoose.model('Retailer', RetailerSchema);