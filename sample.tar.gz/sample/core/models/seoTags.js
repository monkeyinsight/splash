/**
 * Module dependencies.
 */
var mongoose = require('mongoose')
	, Schema = mongoose.Schema


/**
 * User Schema
 */
var SeoTagSchema = new Schema({
	categoryTitle: { type: String, default: ''},
	categoryMetaDescription: { type: String, default: ''},
	siteWideTitle: { type: String, default: ''},
	siteWideMetaDesc: { type: String, default: ''},
	__year__: { type: String, default: ''},
	__voucher_kw__: { type: String, default: ''}
}, {collection: 'seoTags'});


SeoTagSchema.statics = {

	/**
	 * loads all SEO tags
	 */
	getAll: function(cb) {
		this
			.findOne({})
			.exec(cb);
	}
	
};

mongoose.model('SeoTag', SeoTagSchema);