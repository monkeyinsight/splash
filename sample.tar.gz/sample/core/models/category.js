 /**
 * Module dependencies.
 */
var mongoose = require('mongoose')
	, Schema = mongoose.Schema;


/**
 * Category Schema
 */
var CategorySchema = new Schema({
	  id_category: { type: String, default: '' }
	, image: { type: String, default: '' }
	, imageCategoryPageLogo: { type: String, default: '' }
	, name: { type: String, default: '' }
	, seo_url: { type: String, default: '' }
});

CategorySchema.statics = {
	/**
	* Get all categories from DB
	*
	* @param {Function} cb
	* @api private
	*/
	getAll: function(cb) {
		return this
				.find({})
				.sort('name')
				.exec(cb);
	},

	/**
	* Get data based on Category Name
	*
	* @param {Function} cb
	* @api private
	*/
	getCatByName: function(name, cb) {
		return this
				.find({})
				.where('seo_url', name)
				.limit(1)
				.exec(cb);
	}
};



mongoose.model('Category', CategorySchema);