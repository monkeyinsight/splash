/**
 * Module dependencies.
 */
var mongoose = require('mongoose')
	, Schema = mongoose.Schema


/**
 * User Schema
 */
var VoucherSchema = new Schema({
	id_merchant: { type: Number, default: ''},
	id_voucher: { type: Number, default: ''},
	title: { type: String, default: ''},
	affiliate_mode: { type: Number, default: ''},
	affiliate_url: { type: String, default: ''},
	exclusive_voucher: { type: Number, default: ''},
	editors_pick: { type: Number, default: ''},
	caption_1: { type: String, default: ''},
	caption_2: { type: String, default: ''},
	kpi: Number,
	description: { type: String, default: ''},
	retailer_logo: { type: String, default: ''},
	retailer_seo_url: { type: String, default: ''},
	retailer: { type: String, default: ''},
	code: { type: String, default: ''},
	topIndex: { type: Number, default: ''},
	top20Index: { type: Number, default: ''},
	end_time: { type: String }
});

VoucherSchema.statics = {
	/**
	* Searching Vouchers based on Retailers ID
	*
	* @param {String} id
	* @param {Function} cb
	* @api private
	*/
	findByRetailerId: function(id, cb) {
		this.find({id_merchant: id})
			.sort({'kpi': -1})
			.exec(cb);
	}, 
	
	/**
	* Find Voucher by ID
	*
	* @param {String} id
	* @param {Function} cb
	* @api private
	*/
	findById: function(id, cb) {
			this.find({id_voucher: id})
			.exec(cb);
	},

	/**
	 * getting Top20 vouchers
	 */
	getTop20: function(cb) {
		this.find({})
			.sort({'top20Index': 1})
			.limit(20)
			.exec(cb);
	},

	/**
	 * getting Top3 vouchers
	 * if they do not have image take next one
	 */
	getByCategoryName: function(name, limit, cb) {
		this.find({})
			.where('category', name)
			.sort({'kpi': -1})
			.limit(limit)
			.exec(cb);
	}
};

mongoose.model('Voucher', VoucherSchema);