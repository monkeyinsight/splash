/**
 * Module dependencies.
 */

var express = require('express')
	, app = express()
	, fs = require('fs')
	, moment = require('moment')

// Load configurations
// if test env, load example file
var env = process.env.NODE_ENV || 'development'
	, conf = require('../app/config/config')[env]  
	, path = require('path');

conf.root = path.normalize(__dirname + '/..');
conf.coreroot = path.normalize(__dirname);
conf.approot = path.normalize(__dirname + '/../app');

// Bootstrap models
var modelsPath = __dirname + '/models';
fs.readdirSync(modelsPath).forEach(function (file) {
	if (~file.indexOf('.js')) require(modelsPath + '/' + file);
});

// bootstraping Express.js framework
require('./express')(app, conf);

// Bootstrap routes
require('../app/config/routes')(app);

// Start the app by listening on <port>
var port = conf.app.nodeListenPort || 3000;
app.listen(port);
console.log('Express app started on port '+ port);

exports = module.exports = app;