var   http = require('http')
	, https = require('https')
	, urlObj = require('url');

/**
 * connects to the supplied url and executes the callback on success
 * 
 * @param url
 * @param replacements
 * @param callback
 */
function HttpGetUtil(remoteUrl, replacements, callback) 
{
	if(!(this instanceof HttpGetUtil)) return new HttpGetUtil(remoteUrl, replacements, callback);

	//arg validation
	if (typeof remoteUrl === 'undefined' || remoteUrl === '') {
		throw new Error('Empty or no URL supplied! Check your config!');
	}
	
	this.remoteUrl = remoteUrl;
	this.replacements = replacements;
	this.callback = callback;
}

HttpGetUtil.prototype.parseRemoteData = function()
{
	for (var key in this.replacements) {
		this.remoteUrl = this.remoteUrl.replace('<' + key + '>', this.replacements[key]);
	}
	
	//parse the apiUrlRetailers
	var parsedUrl = urlObj.parse(this.remoteUrl);

	var requestObj;
	//which protocil should we use
	if (parsedUrl.protocol == 'https:') {
		requestObj = https;
	} else {
		requestObj = http;
	}
	
	var options = {
		hostname: parsedUrl.host,
		path: parsedUrl.path,
		auth: parsedUrl.auth,
		method: 'GET',
		rejectUnauthorized: false
	};

	var callback = this.callback;
	
	var req = requestObj.request(options, function(res) {
		var buffer = '';

		res.on('data', function(data) {
	        buffer += data;
	    });
		
		res.on('end', function () {
			callback(buffer);
		});
	});
	
	req.end();

	req.on('error', function(e) {
		console.error(e);
		
		//terminate with error 
		process.exit(1);
	});
};

module.exports.HttpGetUtil = HttpGetUtil;