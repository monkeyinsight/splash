
/**
 * Constructor
 * 
 * @param <db instance> db
 */
function SolrUtil(solrClient, lang) {
	if(!(this instanceof SolrUtil)) return new SolrUtil(solrClient, lang);
	this.client = solrClient;
	this.lng = lang || 'en';
}


/**
 * Mapping the fields from DB to Solr
 * This means that we need to add _i, _en(lang), _d for the fields
 * depending of the type of the fields
 * 
 * @param  {JSON} single row from vouchers collection
 * @return {JSON} formatted row of the voucher
 */
SolrUtil.prototype.mapFieldsFromDbToSolr = function(row, moment) {

	var solrTimeFormat = 'YYYY-MM-DDTHH:mm:ss[Z]';

	var v = {};
	var lang = this.lng;
	v['id'] = row.id_voucher;
	v['id_merchant_i'] = row.id_merchant;
	v['code_t'] = row.code;
	v['affiliate_mode_t'] = row.affiliate_mode;
	v['start_time_dt'] = moment(row.start_time).format(solrTimeFormat);
	v['end_time_dt'] =  moment(row.end_time).format(solrTimeFormat);
	v['title_' + lang] = row.title;
	v['exclusive_voucher_i'] = row.exclusive_voucher;
	v['how_it_works_t'] = row.how_it_works;
	v['description_t'] = row.description;
	v['affiliate_url_t'] = row.affiliate_url;
	v['pos_t'] = row.pos;
	v['editors_pick_i'] = row.editors_pick;
	v['manual_pick_t'] = row.manual_pick;
	v['caption_1_' + lang] = row.caption_1;
	v['caption_2_' + lang] = row.caption_2;
	v['deal_source_t'] = row.deal_source;
	v['id_clickout_type_t'] = row.id_clickout_type;
	v['id_voucher_product_image_t'] = row.id_voucher_product_image;
	v['id_affnetwork_t'] = row.id_affnetwork;
	v['merchant_name_' + lang] = row.retailer;
	v['merchant_seo_url_' + lang] = row.retailer_seo_url;
	v['voucher_tags_' + lang + '_m'] = row.tag;
	v['voucher_categories_' + lang + '_m'] = row.category;
	v['product_image_t'] = row.product_image;
	v['retailer_logo_t'] = row.retailer_logo;
	
	return v;
}



/**
 * Reverse Mapping of the fields
 * 
 * @param  {JSON} single row from vouchers collection
 * @return {JSON} formatted row of the voucher
 */
SolrUtil.prototype.mapFieldsFromSolrToDB = function(v) {
	var lang = this.lng;
	var v = {
		'id_voucher' : v['id'],
		'id_merchant' : v['id_merchant_i'],
		'code' : v['code_t'],
		'affiliate_mode' : v['affiliate_mode_t'],
		'start_time' : v['start_time_dt'],
		'end_time' : v['end_time_dt'],
		'title' : v['title_' + lang],
		'exclusive_voucher' : v['exclusive_voucher_i'],
		'how_it_works' : v['how_it_works_t'],
		'creation_time' : v['creation_time_dt'],
		'last_update' : v['last_update_dt'],
		'description' : v['description_t'],
		'affiliate_url' : v['affiliate_url_t'],
		'pos' : v['pos_t'],
		'editors_pick' : v['editors_pick_i'],
		'manual_pick' : v['manual_pick_t'],
		'caption_1' : v['caption_1_' + lang],
		'caption_2' : v['caption_2_' + lang],
		'deal_source' : v['deal_source_t'],
		'id_clickout_type' : v['id_clickout_type_t'],
		'id_voucher_product_image' : v['id_voucher_product_image_t'],
		'id_affnetwork' : v['id_affnetwork_t'],
		'merchant_name' : v['merchant_name_' + lang],
		'retailer_seo_url' : v['merchant_seo_url_' + lang],
		'retailer_image_alt' : v['merchant_image_alt_t'],
		'retailer_image' : v['image_t'],
		'voucher_categories_url' : v['voucher_categories_url_' + lang + '_m'],
		'merchant_categories' : v['merchant_categories_' + lang + '_m'],
		'merchant_categories_url' : v['merchant_categories_url_' + lang + '_m'],
		'voucher_tags' : v['voucher_tags_' + lang + '_m'],
		'voucher_categories' : v['voucher_categories_' + lang + '_m'],
		'product_image' : v['product_image_t'],
		'retailer_logo' : v['retailer_logo_t']
	}
	return v;
}


/**
 * Clearing the query string
 * 
 * @param  {[type]} query [description]
 * @return {[type]}       [description]
 */
SolrUtil.prototype.query = function(queryString) {
	var qString = queryString.replace(/[:"*^<>()]/g, '').replace('/\ +/g', ' '); 
	var q = this.client.createQuery().q(queryString);

	return q;
}



/**
 * Indexing the vouchers into the Solr Server / under Core
 * 
 * @param  {JSON} jsonObj 
 */
SolrUtil.prototype.indexVouchers = function(jsonObj, moment) {
	var client = this.client;
	var tmpObj = [];
	for (i in jsonObj) {
		var v =  this.mapFieldsFromDbToSolr(jsonObj[i], moment);
		tmpObj.push(v);
	}

	client.delete('id','*',function(err,obj) {
	   if (err){
			console.log('\n -- \033[43;31m ERROR during deleting vouchers : ' + err + ' \33[m-- ');
	   } else{
		client.add(tmpObj,function(err,obj) {
		   if (err) {
			  console.log('\n -- \033[43;31m ERROR during deleting vouchers: ' + err + ' \33[m-- ');
		   } else{
			  console.log('\n -- SOLR UPDATED -- ');
			  console.log('Solr added \033[42;1m ' + tmpObj.length + ' \33[m objects!');
			  console.log('\n------------------------------------------');
		   }
		});
	   }
	});	

}

module.exports.SolrUtil = SolrUtil;
