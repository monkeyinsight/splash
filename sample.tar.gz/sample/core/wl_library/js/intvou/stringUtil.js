/**
 * returns true if the first string param starts with the second string param
 * 
 * @param string str
 * @param string input
 * 
 * @return bool
 */
function startsWith(str, input)
{
	return str.substring(0, input.length) === input;
};

//what is available for use outside the class
module.exports.startsWith = startsWith;