/**
 * Constructor
 * 
 * @param <db instance> db
 */
function MongoDbUtil(db, async) {
	if(!(this instanceof MongoDbUtil)) return new MongoDbUtil(db);
	this.db = db;
}

/**
 * flushes and updates the specified collection with
 * the parsed results of the given JSON string
 * 
 * @param string collectionName
 * @param string strJson
 * @param bool noFlushExisting if passed, disables the flushing of existing entries
 */
MongoDbUtil.prototype.updateCollection = function(collectionName, strJson, async) {

	var db = this.db;
	
	var tpmCollectionName = collectionName + '_tmp';


	async.series([

		// creation of tmp Collection
		function(callback) {
			db.createCollection(tpmCollectionName, function(err, tmpCollection) {
				console.log('\n--------------------------------------------------------------------------');
				if (err) {
					console.log('There is an issue with creating new collection: ', err);
					return;
				}


				var rows = [];
				try {
					rows = JSON.parse(strJson);
				} catch(e) {
					console.log(e);
					rows = strJson;
				}

				// changing the type of the data to Numeric if the data is numeric
				for (var i in rows) {
					for (r in rows[i]) {
						if (typeof(rows[i][r]) == 'string' 
							&& rows[i][r] != '' 
							&& rows[i][r] != null 
							&& !isNaN(rows[i][r])) 
						{
							rows[i][r] = parseInt(rows[i][r]);
						}
					}
					tmpCollection.save(rows[i], {w:0});
				}

				console.log('CREATION OF TMP COLLECTION ' + tpmCollectionName + ' objects');
				callback()
			})
			
		},

		// Removing the original collection
		function(callback) {
			db.dropCollection(collectionName, function(err, res) {
				console.log('REMOVING ORIGINAL COLLECTION ' + collectionName);
				if (err) {
					console.log('Error removing the collection: ', err);
				}
				callback()
			})
		},

		// Removing the original collection
		function(callback) {
			db.renameCollection(tpmCollectionName, collectionName, function(err, result) {
				console.log('RENAMING TMP to ORIGINAL COLLECTION ' + collectionName);
				if (err) {
					console.log('error renaming: ', err);
				} else {
					console.log('\033[42;1m Collection ' + collectionName + ' added successfully ! \33[m');	
				}
				console.log('\n--------------------------------------------------------------------------');
				callback()
			})
		}
		
		]
	)
}
	

/**
 * returns the converted DB name from a partner site name
 * 
 * @param string partnerSiteName
 * 
 * @return string 
 */
function getDbName(partnerSiteName) {
	return partnerSiteName.replace(/\./g, '_');
};


//what is available for use outside the class
module.exports.MongoDbUtil = MongoDbUtil;
module.exports.getDbName = getDbName;