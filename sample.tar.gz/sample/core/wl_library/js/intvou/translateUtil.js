var _TRANSLATIONS_TABLE = 'translations';


/**
 * Constructor
 * 
 * initializes i18n using the `translations` table entries
 * 
 * @param Mongoose mongoose
 * @param i18n-next i18n
 * @param String lng
 */
function TranslateUtil(mongoose, i18n, lng) 
{
	if(!(this instanceof TranslateUtil)) return new TranslateUtil(mongoose, i18n, lng);
	this.i18n = i18n;
	this.lng = lng;
	
	var translationSchema = mongoose.Schema({
		current: mongoose.Schema.Types.Mixed
	});

	this._translationModel = mongoose.model(_TRANSLATIONS_TABLE, translationSchema);
	
}


/**
 * loads translations
 * 
 * return void
 */
TranslateUtil.prototype.loadTranlslations = function(callback) 
{
	var i18n = this.i18n;

	var lng = this.lng;
	//retrieve all for the current lang from MongoDb
	this._translationModel.find({}, function (err, result) {

		if (err) {
			return handleError(err);
		}
		
		if (result.length > 0) {
			result = result[0];
			
			var translationsRes = result;

			i18n.init({
		    	saveMissing: false,
				debug: true,

				//NB: YES!, all of the following options ARE needed to only use 1 lang...
				lng: lng,
				fallbackLng: lng,
				load: lng,
				supportedLngs: [lng],
				//we don't need to auto detect lang from user cookies or headers
				useCookie: false,
				detectLngFromHeaders: false,
				resStore: translationsRes
			});
		}
	});			
}



//what is available for use outside the class
module.exports.TranslateUtil = TranslateUtil;