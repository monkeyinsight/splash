/**
 * Module dependencies.
 */

var express = require('express')
	, less = require('less-middleware')
	, mongoose = require('mongoose')
	, fs = require('fs')
	, path = require('path')
	, url = require("url")
	, mongoDbUtilClass = require('./wl_library/js/intvou/mongoDbUtil.js')
	, i18n = require('i18next')
	, moment = require('moment')
	, crypto = require('crypto')


module.exports = function (app, config) 
{
	app.set('showStackError', config.app.debug);
   	app.locals.conf = config.app;
    
    //needed so that the remote Addr is properly passed by Nginx in req.ip
    app.enable('trust proxy');
	
	
	//initialize cookie support
	app.use(express.cookieParser());
	
	var secretHash = crypto.randomBytes(20).toString('hex');
	//set the session cookie and expiry date
	//30 minutes as done by Google
	var timeout = 30 * 60 * 1000;

	//NB: not using express.session as it's not suitable for production env
	//according to some tests (http://stackoverflow.com/questions/8749907/what-is-a-good-session-store-for-a-single-host-node-js-production-app)
	//cookieSession seems faster than redis & mongo
	app.use(express.cookieSession(
        {
            secret: secretHash,
    		cookie: { 
    			//both maxAge and expires so that ALL browsers know when to delete the cookie
    			maxAge  : timeout
			} 
		}));
	

	//get the DB name for this partner site
	var dbName = mongoDbUtilClass.getDbName(config.app.partnerSiteName);

	config.db = config.app.dbHost + dbName;

	// Bootstrap db connection
	mongoose.connect(config.db);

	//because the system is not multilingual yet, only specify 1 lang - current
	var lng = 'current';
	
	//instantiate the `class` that would help us init i18n from MongoDb
	var translateUtil = require('./wl_library/js/intvou/translateUtil.js').TranslateUtil(mongoose, i18n, lng);

	// load the translations from MongoDb
	translateUtil.loadTranlslations();
	
	app.locals.__ = i18n.t;
	

	!!i18n.options.lng && app.use(i18n.handle);
	
	app.use(less({
		dest: config.approot + '/public/css',
		src: config.approot + '/public/less',
		prefix: '/css',
		debug: config.app.debug,
		force: config.app.debug
	}));

	// should be placed before express.static
	// compress the response of the objects
	app.use(express.compress({
		filter: function (req, res) {
		  return /json|text|javascript|css/.test(res.getHeader('Content-Type'));
		},
		level: 9
	}));

	// this will end Express.js for the static content
	app.use(express.static(config.approot + '/public'));

	app.use(function(req, res, next) {
		app.locals.url = req.originalUrl;
		req.conf = config.app;
		

		//only show the tracking pixel the first time the WL site is opened 
		//store a flag in the session so that we later could send them to
		//the cuponation bridge page
		if (! req.session.shownTrackingPixelUrl) {
			//indicate as already shown
			req.session.shownTrackingPixelUrl = true;
			
			//the pixel tracking URL is needed so that we inform the cuponation site about each visit
			req.conf.parsedTrackingPixelUrl = config.app.trackingPixelUrl + '?';
			
			//the whole request URI must be stored, so that it's parsed on the cuponation site
			
			var requestUri = req.url;
			if (requestUri.indexOf("?") != -1) {
				requestUri += '&';
			} else {
				requestUri += '?';
			}
			
			//WL clients always `cooperation` as utm_param; and the WL partner name as utm_partner
			requestUri += 'utm_medium=cooperation&utm_partner=' + config.app.partnerSiteName;
			//also include the clientId - needed to get the correct aff new URL for the redirect 
			//at the cuponation bridge page
			requestUri += '&clientId=' + config.app.clientId;
			
			req.session.requestUri = (new Buffer(requestUri).toString('base64'));
			req.conf.parsedTrackingPixelUrl += '&requestUri=' + req.session.requestUri;
			

			//store the referer as well
			req.session.referer = '/';
			if (req.headers.referer) {
				req.session.referer = (new Buffer(req.headers.referer).toString('base64'));
			}
			
			req.conf.parsedTrackingPixelUrl += '&referrerUri=' + req.session.referer;
			
		//if shown already, don't show anymore
		} else {
			req.conf.parsedTrackingPixelUrl = '';
		}

		req.conf.utmParams = 'utm_medium=cooperation&utm_partner=' + config.app.partnerSiteName;
		
		var hash = crypto.createHash('md5').update(config.app.partnerSiteName + req.originalUrl).digest("hex");

		// we will use this key for storing the redis data
		// the key is combination of partnersite + the original url. By this approach we will be sure that we will not override 
		// same urls for different whitelabel clients
		req.redisKey = hash;

		app.set('showStackError', config.app.debug);

		var date = moment().format('MMM YYYY');
		req.seo = {
			voucherKw: 'coupons',
			date: date
		};

		
        //Log the current page visit IP to stdout (which is redirected to a file)
        //var remoteIp = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
        console.log("visit from: " + req.ip);
		
		next();
	});



	// set views path, template engine and default layout
	app.set('views', config.approot + '/views');
	app.set('view engine', 'jade');

	app.configure(function () {

      	app.locals.moment = require('moment');

		app.use(app.router);



		// assume "not found" in the error msgs
		// is a 404. this is somewhat silly, but
		// valid, you can do whatever you like, set
		// properties, use instanceof etc.
		app.use(function(err, req, res, next) {
			  // treat as 404
		    if (err.message
				&& (~err.message.indexOf('not found')
				|| (~err.message.indexOf('Cast to ObjectId failed')))) {
				return next()
			}
			
			// error page
			res.status(500).render('500', { error: err.stack })
		});

		// assume 404 since no middleware responded
		app.use(function(req, res, next){
			res.status(404).render('404', {
				url: req.originalUrl,
				error: 'Not found'
			})
		});

		// don't use logger for test env
		if (process.env.NODE_ENV !== 'test') {
			app.use(express.logger('dev'))
		}
	})
}